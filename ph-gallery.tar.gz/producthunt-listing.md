# ChurnGuard — Product Hunt Listing Copy

## Tagline (60 char max, outcome-driven)
Recover 20-30% more failed Stripe payments on autopilot

## Description (for the product page)
Every SaaS on Stripe loses ~9% of MRR to failed subscription payments — expired cards, insufficient funds, bank declines. Stripe's built-in retries recover some, but they stop after 4 attempts with generic emails.

ChurnGuard layers an intelligent 7-step dunning sequence on top of Stripe. Multi-channel (email + SMS), timed for maximum recovery based on real payment data. Our sequence recovers 73% of failed payments vs. the industry average of 47%.

🎯 What makes ChurnGuard different:
• 60-second setup — connect your Stripe account via API key, we handle everything else
• Smart sequences adapt to decline reason (soft decline vs. hard decline — different approaches)
• Real dashboard showing exactly how much revenue you've recovered
• $49/mo for up to $5K MRR — 5-10x cheaper than Churn Buster/Gravy/Slicker
• Self-serve — no sales calls, no demos, no human interaction required

🔌 Built on:
Stripe API + SendGrid + Turso (edge SQLite) + FastAPI

Today's launch offer: Free 14-day trial, no credit card required.

## Maker's First Comment (post within 2 min of launch)
Hey Product Hunt! 👋

I built ChurnGuard because I kept seeing SaaS founders leave thousands on the table from failed subscription payments. Stripe does basic retries, but the recovery rate drops off hard after a few attempts.

ChurnGuard adds what Stripe doesn't:
- A proven 7-step dunning sequence (studied the data on what timing + messaging actually converts)
- Multi-channel (email + SMS) — not just email
- Decline-aware — different strategy for "insufficient funds" vs "stolen card"
- A dashboard that shows you exactly how much money you got back

The whole thing is self-serve — connect your Stripe API key and it just works. I built it for founders who don't want to talk to anyone (myself included).

Tech stack: Python/FastAPI, Turso (distributed SQLite), SendGrid, hosted on Render.

I'd love feedback from anyone running a SaaS on Stripe — what's your current churn recovery setup? What's been the biggest pain point?

## Topics/Categories
- SaaS
- Developer Tools
- Payments

## Gallery Images Needed
1. Hero: landing page hero section
2. Dashboard: customer dashboard showing recovery stats
3. Pricing: pricing tiers
4. Connect flow: Stripe API key connection page
